This package contains the font-bitstream-type1 tarball downloaded from
http://xorg.freedesktop.org/releases/individual/font/
converted to .ttf format.

----------------
HOW TO INSTALL
----------------
On Windows Vista/7

  Right click on each font file, and select "Install".

On Windows XP

  Open Control Panel/Fonts, and copy (or drag) all the fonts 
  files into the directory.

On Ubuntu/Linux

  Double click each file to open it in font-viewer, and click "Install".
    (or)
  Copy all files to /usr/share/fonts/truetype, and run
  fc-cache -fv

----------------


(c) Copyright 1989-1992, Bitstream Inc., Cambridge, MA.

You are hereby granted permission under all Bitstream propriety rights
to use, copy, modify, sublicense, sell, and redistribute the 4 Bitstream
Charter (r) Type 1 outline fonts and the 4 Courier Type 1 outline fonts
for any purpose and without restriction; provided, that this notice is
left intact on all copies of such fonts and that Bitstream's trademark
is acknowledged as shown below on all unmodified copies of the 4 Charter
Type 1 fonts.

BITSTREAM CHARTER is a registered trademark of Bitstream Inc.
